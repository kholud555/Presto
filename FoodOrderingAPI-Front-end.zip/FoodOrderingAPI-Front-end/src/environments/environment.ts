export const environment = {
  production: false,
  apiUrl: "https://prestoordering.somee.com/api"
};