export const environment = {
  production: true,
  apiUrl: "https://prestoordering.somee.com/api"
};