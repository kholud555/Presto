import { StatustitlePipe } from './statustitle-pipe';

describe('StatustitlePipe', () => {
  it('create an instance', () => {
    const pipe = new StatustitlePipe();
    expect(pipe).toBeTruthy();
  });
});
