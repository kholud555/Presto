import { Component } from '@angular/core';

@Component({
  selector: 'app-firstcomponent',
  imports: [],
  templateUrl: './firstcomponent.component.html',
  styleUrl: './firstcomponent.component.css'
})
export class FirstcomponentComponent {

}
