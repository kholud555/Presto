import { Component } from '@angular/core';

@Component({
  selector: 'app-billing-page',
  imports: [],
  templateUrl: './billing-page.component.html',
  styleUrl: './billing-page.component.css'
})
export class BillingPageComponent {

}
