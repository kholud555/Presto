import { Component } from '@angular/core';

@Component({
  selector: 'app-head-user',
  imports: [],
  templateUrl: './head-user.component.html',
  styleUrl: './head-user.component.css'
})
export class HeadUserComponent {

}
