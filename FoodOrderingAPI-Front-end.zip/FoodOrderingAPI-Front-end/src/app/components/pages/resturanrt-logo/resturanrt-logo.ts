import { Component } from '@angular/core';

@Component({
  selector: 'app-resturanrt-logo',
  imports: [],
  templateUrl: './resturanrt-logo.html',
  styleUrl: './resturanrt-logo.css'
})
export class ResturanrtLogo {

}
