export interface ISideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}
