export interface Message {
     content: string;
  isOutgoing: boolean;
  time: string;
}
